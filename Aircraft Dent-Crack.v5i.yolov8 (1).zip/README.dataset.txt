# Aircraft Dent&Crack  > 2022-09-07 11:43am
https://universe.roboflow.com/aircraft-detection-hpzth/aircraft-dent-crack

Provided by a Roboflow user
License: Public Domain

